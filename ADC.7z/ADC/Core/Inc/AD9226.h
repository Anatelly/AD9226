#ifndef __AD9225_H
#define __AD9225_H

#include "main.h"

typedef enum
{
    AD_OK,
    AD_ERROR
} AD_State;

AD_State AD_Recieve(uint16_t* adcBuff, uint32_t sizeBuff);

#endif