/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"
#include "AD9226.h"

#include <stdio.h>
#include <string.h>
#include <inttypes.h>

/*Определение порта А*/
#define D0 GPIO_PIN_0
#define D1 GPIO_PIN_1
#define D2 GPIO_PIN_4
#define D3 GPIO_PIN_5
#define D4 GPIO_PIN_6
#define D5 GPIO_PIN_7
#define D6 GPIO_PIN_8
#define D7 GPIO_PIN_9
#define D8 GPIO_PIN_10
#define D9 GPIO_PIN_11
#define D10 GPIO_PIN_12
#define D11 GPIO_PIN_15 
/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
