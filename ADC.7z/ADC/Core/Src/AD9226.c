/*Подключение AD9226 осуществляется к выводам stm32 PA0-PA12,PA15
  Вход синхронизации CLK подключается к выходу генератора на МК (PB0)*/

#include "AD9226.h"

AD_State AD_Recieve(uint16_t *adcBuff, uint32_t sizeBuff) // буфер для данных с АЦП, размер буфера
{
    uint32_t count = 0; // счетчик

    // if (sizeBuff == 0 || adcBuff == NULL)
    //     return AD_ERROR;

    for (uint8_t _ = 0; _ < 10; _++)
    {
    }; // задержка, для установки данных

    while (count < sizeBuff) // пока буфер не переполнился
    {
        /*Читаем данные с параллельного пората АЦП*/
        adcBuff[count] = HAL_GPIO_ReadPin(GPIOA, D0) << 0 | HAL_GPIO_ReadPin(GPIOA, D1) << 1 | HAL_GPIO_ReadPin(GPIOA, D2) << 2 |
                          HAL_GPIO_ReadPin(GPIOA, D3) << 3 | HAL_GPIO_ReadPin(GPIOA, D4) << 4 | HAL_GPIO_ReadPin(GPIOA, D5) << 5 |
                          HAL_GPIO_ReadPin(GPIOA, D6) << 6 | HAL_GPIO_ReadPin(GPIOA, D7) << 7 | HAL_GPIO_ReadPin(GPIOA, D8) << 8 |
                          HAL_GPIO_ReadPin(GPIOA, D9) << 9 | HAL_GPIO_ReadPin(GPIOA, D10) << 10| HAL_GPIO_ReadPin(GPIOA, D11) << 11;
        count++;
    }
    // return AD_OK;
}
